package com.example.ohmycost;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class AddActivity extends MainActivity {

    TextView activityTxtv;
    Button selectBtn,applyBtn,okButton;
    EditText entercostEdt,enteractivityEdt;
    RadioGroup activityGroup;
    RadioButton radioButton;
    String priceTxt,activityTxt,activityTxt2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        //Windowpopup1

        AlertDialog.Builder mBuilder = new AlertDialog.Builder(AddActivity.this);
        final View mView = getLayoutInflater().inflate(R.layout.windowpopup, null);
        mBuilder.setView(mView);
        final AlertDialog dialog = mBuilder.create();

        activityTxtv = (TextView) findViewById(R.id.activityTxtv);
        selectBtn = (Button) findViewById(R.id.selectBtn);
        selectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.show();
            }
        });

        activityGroup = (RadioGroup) mView.findViewById(R.id.activityGroup);
        applyBtn = (Button) mView.findViewById(R.id.applyBtn);
        applyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int radioId = activityGroup.getCheckedRadioButtonId();
                radioButton = mView.findViewById(radioId);
                if (radioButton.getText().toString() == "OTHERS") {
                    enteractivityEdt = (EditText) findViewById(R.id.enteractivityEdt);
                    activityTxt = enteractivityEdt.getText().toString();
                } else {
                    activityTxt = radioButton.getText().toString();
                }
                okButton = (Button) findViewById(R.id.okBtn);
                okButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        entercostEdt = findViewById(R.id.entercostEdt);
                        priceTxt = entercostEdt.getText().toString();
                        AddData(activityTxt,priceTxt);
                        openOkbtn();
                    }
                });
                activityTxtv.setText(activityTxt);
                dialog.dismiss();
            }
        });


    }
    public void openOkbtn() {
        Intent intent = new Intent(AddActivity.this, MainActivity.class);
        startActivity(intent);
    }
    public void AddData(String activity,String price){
        boolean insertData = myDB.addData(activity,price);

        if(insertData==true){
            Toast.makeText(AddActivity.this,"Successfully Entered Data!",Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(AddActivity.this,"Something went wrong :(.",Toast.LENGTH_LONG).show();
        }
    }
}
