package com.example.ohmycost;

public class Date {
    private String activity;
    private String price;

    public Date(String activityText, String priceText) {
        activity = activityText;
        price = priceText;
    }

    public String getActivity() {
        return activity;
    }

    public String getPrice() {
        return price;
    }
}
