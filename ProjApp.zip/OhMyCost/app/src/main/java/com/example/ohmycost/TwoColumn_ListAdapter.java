package com.example.ohmycost;

import android.content.Context;
import android.icu.text.Transliterator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class TwoColumn_ListAdapter extends ArrayAdapter<Date> {

    private LayoutInflater mInflater;
    private ArrayList<Date> dates;
    private int mViewResourceId;

    public TwoColumn_ListAdapter(@NonNull Context context, int textViewResourceId,ArrayList<Date> dates) {
        super(context, textViewResourceId,dates);
        this.dates = dates;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mViewResourceId = textViewResourceId;
    }

    public View getView(int position, View convertView, ViewGroup parents) {
        convertView = mInflater.inflate(mViewResourceId,null);

        Date user = dates.get(position);

        if (user != null) {
            TextView activity = (TextView) convertView.findViewById(R.id.textActivity);
            TextView price = (TextView) convertView.findViewById(R.id.textPrice);

            if (activity != null) {
                activity.setText((user.getActivity()));
            }
            if (price != null) {
                price.setText((user.getPrice()));
            }
        }
        return convertView;
    }
}

