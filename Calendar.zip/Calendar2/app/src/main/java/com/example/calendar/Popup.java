package com.example.calendar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Popup extends AppCompatActivity {

    RadioGroup radioGroup;
    RadioButton radioButton1;
    RadioButton radioButton2;
    RadioButton radioButton3;
    TextView seclectView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_popup);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int)(width*.8),(int)(height*.4));

        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        seclectView = (TextView) findViewById(R.id.selectView);

        radioButton1 = (RadioButton) findViewById(R.id.food);
        radioButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int radioId = radioGroup.getCheckedRadioButtonId();
                radioButton1 = findViewById(radioId);
                Intent intent = new Intent(Popup.this, AddButton.class);
                intent.putExtra("MyValue",radioButton1.getText());
                startActivity(intent);
            }
        });

        radioButton2 = (RadioButton) findViewById(R.id.bus);
        radioButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int radioId = radioGroup.getCheckedRadioButtonId();
                radioButton2 = findViewById(radioId);
                Intent intent = new Intent(Popup.this, AddButton.class);
                intent.putExtra("MyValue",radioButton2.getText());
                startActivity(intent);
            }
        });

        radioButton3 = (RadioButton) findViewById(R.id.others);
        radioButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int radioId = radioGroup.getCheckedRadioButtonId();
                radioButton3 = findViewById(radioId);
                Intent intent = new Intent(Popup.this, AddButton.class);
                intent.putExtra("MyValue",radioButton3.getText());
                startActivity(intent);
            }
        });



        /*radioGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int radioId = radioGroup.getCheckedRadioButtonId();
                radioButton = findViewById(radioId);
                seclectView.setText(radioButton.getText());
                Intent intent = new Intent(Popup.this, AddButton.class);
                intent.putExtra("MyValue",radioButton.getText());
                startActivity(intent);
                /*Intent intent = new Intent(Popup.this, AddButton.class);
                intent.putExtra("MyValue", radioButton.getText());
                startActivity(intent);
            }
        });*/

        /*radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                //seclectView.setText(radioButton.getText());
            }
        });*/
        //RadioButton food = findViewById(R.id.food);
        //RadioButton bus = findViewById(R.id.bus);
        //RadioButton others = findViewById(R.id.others);
        //radioButton.setOnClickListener(new View.OnClickListener() {
           // @Override
           // public void onClick(View v) {
             //   int radioId = radioGroup.getCheckedRadioButtonId();

               // radioButton = findViewById(radioId);

                //activityView.setText(radioButton.getText());
           // }
       // });


    }
    public void checkButton1(View v) {
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton1 = findViewById(radioId);


        //Intent intent1 = new Intent(this, AddButton.class);
        //startActivity(intent1);
    }
    public void checkButton2(View v) {
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton2 = findViewById(radioId);
    }
    public void checkButton3(View v) {
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton3 = findViewById(radioId);
    }
}
