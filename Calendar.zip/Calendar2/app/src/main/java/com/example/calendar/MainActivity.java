package com.example.calendar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TableRow;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    CalendarView calendarView;
    private static final String TAG ="MainActivity";
    TextView myDate;
    Button addButton;
    Button graphButton;

    TextView foodShow;
    TextView costFood;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        graphButton = (Button) findViewById(R.id.graphButton);
        graphButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGraphButton();
            }
        });

        calendarView = (CalendarView) findViewById(R.id.calendarView);
        myDate = (TextView) findViewById(R.id.myDate);

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String date = dayOfMonth + "/" + (month + 1) + "/" + year;
                myDate.setText(date);
                String[] list = new String[10];

                /*Intent intent = new Intent(MainActivity.this, AddButton.class);
                intent.putExtra("date",date);
                startActivity(intent);*/

                addButton = (Button) findViewById(R.id.addButton);
                addButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openAddButton();
                    }
                });
            }
        });

        foodShow = (TextView) findViewById(R.id.foodShow);
        Intent incomingIntent1 = getIntent();
        String value1 = incomingIntent1.getStringExtra("FOOD");
        foodShow.setText(value1);

        costFood = (TextView) findViewById(R.id.costFood);
        Intent incomingIntent2 = getIntent();
        String value2 = incomingIntent2.getStringExtra("costFood");
        costFood.setText(value2);


    }

    public void openAddButton() {
        Intent intent1 = new Intent(this, AddButton.class);
        startActivity(intent1);
    }

    public void openGraphButton() {
        Intent intent2 = new Intent(this, GraphButton.class);
        startActivity(intent2);
    }
}