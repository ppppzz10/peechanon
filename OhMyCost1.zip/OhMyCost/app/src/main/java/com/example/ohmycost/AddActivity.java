package com.example.ohmycost;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class AddActivity extends MainActivity {

    public static final String EXTRA_TEXT = "com.example.application.example.EXTRA_TEXT";
    public static final String EXTRA_NUMBER = "com.example.application.example.EXTRA_NUMBER";

    RadioGroup activityGroup;
    RadioButton radioButton;
    Button selectBtn,applyBtn,okBtn,viewBtn;
    TextView activityTxtv;
    String activity,costStr;
    Integer cost;
    EditText enteractivityEdt;
    EditText entercostEdt;
    String myString = "Please enter cost.";

    DatabaseHelper myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        //Windowpopup1

        AlertDialog.Builder mBuilder = new AlertDialog.Builder(AddActivity.this);
        final View mView = getLayoutInflater().inflate(R.layout.windowpopup, null);
        mBuilder.setView(mView);
        final AlertDialog dialog = mBuilder.create();

        activityTxtv = (TextView) findViewById(R.id.activityTxtv);
        selectBtn = (Button) findViewById(R.id.selectBtn);
        selectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.show();
            }
        });

        activityGroup = (RadioGroup) mView.findViewById(R.id.activityGroup);
        applyBtn = (Button) mView.findViewById(R.id.applyBtn);
        applyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int radioId = activityGroup.getCheckedRadioButtonId();
                radioButton = mView.findViewById(radioId);
                activity = radioButton.getText().toString();
                if (activity == "OTHERS")
                {
                    enteractivityEdt = (EditText) findViewById(R.id.enteractivityEdt);
                    activityTxtv.setText(enteractivityEdt.getText().toString());
                }
                else
                {
                    activityTxtv.setText(activity);
                }
                dialog.dismiss();
            }
        });

        //Start Database

        myDB =new DatabaseHelper(this);

        //ViewButton

        viewBtn = (Button) findViewById(R.id.viewBtn);
        viewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddActivity.this,ViewListContents.class);
                startActivity(intent);
            }
        });

        //OKbutton

        entercostEdt = (EditText) findViewById(R.id.entercostEdt);
        okBtn = (Button) findViewById(R.id.okBtn);

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (radioButton.length() != 0 && entercostEdt.length() !=0) {
                    costStr = entercostEdt.getText().toString();
                    cost = Integer.parseInt(costStr);
                    AddData(activity,costStr);
                }else {
                    Toast.makeText(AddActivity.this, "You must something in the text field!",Toast.LENGTH_LONG).show();
                }
            }
        });

    }
    public void openOkBtn() {
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
    public void AddData(String activity, String price) {
        boolean insertData = myDB.addData(activity,price);

        if (insertData == true) {
            Toast.makeText(AddActivity.this, "Data inserted successfully!",Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(AddActivity.this, "Something went wrong :(.",Toast.LENGTH_LONG).show();
        }
    }
}
