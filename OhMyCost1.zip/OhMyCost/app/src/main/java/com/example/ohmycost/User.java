/*package com.example.ohmycost;

public class User {
    private String activity;
    private String price;

    public User(String activityText, String priceText) {
        activity = activityText;
        price = priceText;
    }

    public String getActivity() {
        return activity;
    }

    public String getPrice() {
        return price;
    }
}*/
