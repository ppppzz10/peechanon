package com.example.ohmycost;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.versionedparcelable.ParcelField;

import java.util.ArrayList;

public class ViewListContents extends AppCompatActivity {

    DatabaseHelper myDB;
    ListView listView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewvontents_layout);

        listView = (ListView) findViewById(R.id.listView);
        myDB = new DatabaseHelper(this);

        ArrayList<String> theList1 = new ArrayList<>();
        ArrayList<String> theList2 = new ArrayList<>();
        Cursor data = myDB.getListContents();

        if (data.getCount()  == 0) {
            Toast.makeText(ViewListContents.this, "There is nothing in this database!", Toast.LENGTH_LONG).show();
        } else {
            while (data.moveToNext()) {
                theList1.add(data.getString(1));
                theList2.add(data.getString(2));
                ListAdapter listAdapter1 = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,theList1);
                ListAdapter listAdapter2 = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,theList2);
                listView.setAdapter(listAdapter1)   ;
            }
        }
    }
}
