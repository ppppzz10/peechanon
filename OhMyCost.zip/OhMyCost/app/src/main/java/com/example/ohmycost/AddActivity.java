package com.example.ohmycost;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class AddActivity extends MainActivity {

    Dialog myDialog;

    RadioGroup activityGroup;
    RadioButton radioButton;
    Button selectBtn,applyBtn;
    TextView activityTxtv;
    String activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        //Windowpopup

        myDialog = new Dialog(this);
        activityTxtv = (TextView) findViewById(R.id.activityTxtv);
        selectBtn = (Button) findViewById(R.id.selectBtn);
        selectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.setContentView(R.layout.windowpopup);
                activityGroup = (RadioGroup) myDialog.findViewById(R.id.activityGroup);
                applyBtn = (Button) myDialog.findViewById(R.id.applyBtn);
                applyBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int radioId = activityGroup.getCheckedRadioButtonId();
                        radioButton = findViewById(radioId);
                        String activity = radioButton.getText().toString();
                        myDialog.dismiss();
                    }
                });
                myDialog.show();
            }
        });

    }
}
