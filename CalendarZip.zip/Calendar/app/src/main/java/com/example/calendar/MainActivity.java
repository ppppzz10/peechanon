package com.example.calendar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    ImageView splash;
    TextView text1,text2;
    Animation animation;

    CalendarView calendar;
    TextView myDate;

    Button graphBtn,addBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Splash Animation

        splash = (ImageView) findViewById(R.id.splash);
        text1 = (TextView)findViewById(R.id.text1);
        text2 = (TextView) findViewById(R.id.text2);

        animation = AnimationUtils.loadAnimation(this,R.anim.animation);
        splash.animate().translationY(-1350).setDuration(800).setStartDelay(300);
        text1.animate().translationY(-760).setDuration(800).setStartDelay(300);
        text2.animate().translationY(-760).setDuration(800).setStartDelay(300);

        //Calendar

        calendar = (CalendarView) findViewById(R.id.calendar);
        myDate = (TextView) findViewById(R.id.myDate);

        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String date = dayOfMonth + " - " +(month + 1) + " - " + year;
                myDate.setText(date);
            }
        });

        //AnimationButton

        graphBtn = (Button) findViewById(R.id.graphBtn);
        graphBtn.animate().translationX(350).setDuration(800).setStartDelay(300);
        addBtn = (Button) findViewById(R.id.addBtn);
        addBtn.animate().translationX(-350).setDuration(800).setStartDelay(300);

    }
}
